// import * as React from 'react';
// import Paper from '@mui/material/Paper';
// import {
//   Chart,
//   PieSeries,
//   Title,
// } from '@devexpress/dx-react-chart-material-ui';
// import { Animation } from '@devexpress/dx-react-chart';
// import { Box } from '@mui/material';

// const data = [
//   { region: 'Asia', val: 4119626293 },
//   { region: 'Africa', val: 1012956064 },
//   { region: 'Northern America', val: 344124520 },
//   { region: 'Latin America and the Caribbean', val: 590946440 },
//   { region: 'Europe', val: 727082222 },
//   { region: 'Oceania', val: 35104756 },
// ];

// export default class DoughNut extends React.PureComponent {
//     constructor(props) {
//         super(props);
    
//         this.state = {
//           data,
//         };
//       }
//       render() {
//         const { data: chartData } = this.state;
    
//         return (
//             <Box component="block" sx={{  width: 100,
//                 height: 200}}>
//           <Paper>
//             <Chart
//               data={chartData}
//             >
//               <PieSeries
//                 valueField="val"
//                 argumentField="region"
//                 innerRadius={0.3}
//                 outerRadius={0.6}
//               />
//               {/* <Title
//                 text="Habit Forming"
//               /> */}
//               <Animation />
//             </Chart>
//           </Paper>
//     // </Box>
//         );
//       }
//     }
import{ Chart as ChartJs,
  ArcElement,
  Tooltip,
  Legend
} from 'chart.js'
import React from 'react'

import { Doughnut } from 'react-chartjs-2'
ChartJs.register(
  ArcElement,
  Tooltip,
  Legend

)

const DoughNut1 = (props) => {
  const data={
    labels:['Yes','No'],
    datasets:[{
      label:'Poll',
      data:props.dataArray,
      backgroundColor:['#1e90ff','	#00FF00'],
      borderColor:['#1e90ff','	#00FF00',]
    }]

  }
  const options={

  }
  return (
    <div>
    <div style={{height:'100%',width:'100%'}}>
      <Doughnut
      data={data}
      options={options}>
      </Doughnut>
    </div>
    </div>
  )
}

export default DoughNut1



