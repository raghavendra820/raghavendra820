import React from 'react'
import FileUpload from './FileUpload'
import { Box } from '@mui/material'
import Card from './Card'
import {Grid} from '@mui/material'
import Bargraph1 from './Bargraph'
import Linegraph from './Linegraph'
const Home = () => {
  return (
    <div>
        <FileUpload/>
        <Box component="span" sx={{ p: 2, width: 300, height: 300 }}>
        </Box>
        <Grid container spacing={3} my={-0.9} justifyContent="center">
          <Card desc="Score" dataArray={[2,6]}/>
          <Card desc="Completeness" dataArray={[3,4]}/>
          <Card desc="Uniqueness" dataArray={[1,6]}/>
        </Grid>
        <Bargraph1/>
        <Linegraph/>
    </div>
  )
}

export default Home