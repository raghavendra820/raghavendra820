import React, { useState } from 'react';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import NativeSelect from '@mui/material/NativeSelect';
import { Grid } from '@mui/material';

const Dropdown = (props) => {
    
    
  return (
    
    <Box sx={{ maxWidth: 240,width: 200}} mx={5}>
      <FormControl fullWidth>
        <InputLabel variant="standard" htmlFor="uncontrolled-native">
          Current Selection
        </InputLabel>
        <NativeSelect
          defaultValue={10}
          inputProps={{
            name: 'age',
            id: 'uncontrolled-native',
          }}
        >
          <option value={10}>{props.desc.replace(/['"]+/g, '')}</option>
          <option value={20}>Dataset1.csv</option>
          <option value={30}>Dataset2.csv</option>
        </NativeSelect>
      </FormControl>
    </Box>
    
  )
}

export default Dropdown