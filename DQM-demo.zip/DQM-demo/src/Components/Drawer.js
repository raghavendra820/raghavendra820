import * as React from "react";
import PropTypes from "prop-types";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import Divider from "@mui/material/Divider";
import Drawer from "@mui/material/Drawer";
import Card from "./Card";
import IconButton from "@mui/material/IconButton";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import MenuIcon from "@mui/icons-material/Menu";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import FileUpload from "./FileUpload";
import SettingsApplicationsRoundedIcon from "@mui/icons-material/SettingsApplicationsRounded";
import { Container, Grid } from "@mui/material";
import Bargraph1 from './Bargraph'
import Linegraph from './Linegraph'
import logo from './logo-3.png'
import HomeIcon from '@mui/icons-material/Home';
import SourceIcon from '@mui/icons-material/Source';
import InsightsIcon from '@mui/icons-material/Insights';
import SettingsPage from "../Pages/SettingsPage";
import Insightpage from "../Pages/Insightpage";
import SourcePage from "../Pages/SourcePage";
import {
  BrowserRouter as Router,
  Switch, Route, Link
} from "react-router-dom";
import Home from './Home'
import { useState } from "react";

const drawerWidth = 210;


function ResponsiveDrawer(props) {
const [first, setfirst] = useState("Home")
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };
// const Drawer = () => {
//   return (
//     <div>Drawer</div>
//   )
// }

// export default Drawer
  const drawer = (
    <div>
      <div class="site-logo" style={{backgroundColor:'#fff',width:'60px',height: '60px',display: 'flex',paddingTop:'-20px',marginBottom:"-60px",marginLeft:"30px"}}>
            <img src={logo} alt="logo" />
  </div>

      <Toolbar />
   {/* <img src="https://via.placehol" alt="logo"/> */}
      <Divider />
      <List>
      <Link to="/" style={{textDecoration:'none',color:'black'}} onClick={()=>{setfirst("Home")}}>
          <ListItem key="Home"  disablePadding>
            <ListItemButton>
              <ListItemIcon>
                <HomeIcon />
              </ListItemIcon>
              <ListItemText primary="Home" />
            </ListItemButton>
          </ListItem>
      </Link>
        <Link to="/source" style={{textDecoration:'none',color:'black'}} onClick={()=>{setfirst("Source")}}>
          <ListItem key="Add Source" disablePadding>
            <ListItemButton>
              <ListItemIcon>
                <SourceIcon />
              </ListItemIcon>
              <ListItemText primary="Add Source" />
            </ListItemButton>
          </ListItem>
        </Link>

         <Link to="/insights" style={{textDecoration:'none',color:'black'}} onClick={()=>{setfirst("Insights")}}>

          <ListItem key="Insights" disablePadding>
            <ListItemButton>
              <ListItemIcon>
                <InsightsIcon />
              </ListItemIcon>
              <ListItemText primary="Insights" />
            </ListItemButton>
          </ListItem>
          </Link>
        <Link to="/settings" style={{textDecoration:'none',color:'black'}} onClick={()=>{setfirst("Settings")}}>
          <ListItem key="Settings" disablePadding>
            <ListItemButton>
              <ListItemIcon>
                <SettingsApplicationsRoundedIcon />
              </ListItemIcon>
              <ListItemText primary="Settings" />
            </ListItemButton>
          </ListItem>        
        </Link>
      </List>
    </div>
  );

  const container =
    window !== undefined ? () => window().document.body : undefined;

  return (
    <Router>
    
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar
        position="fixed"
        sx={{
          width: { sm: `calc(100% - ${drawerWidth}px)` },
          ml: { sm: `${drawerWidth}px` },
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={{ mr: 2, display: { sm: "none" } }}
          >
            <MenuIcon />
          </IconButton>

          <Typography variant="h6" noWrap component="div" marginLeft={'0px'}>
            {first}
          </Typography>
        </Toolbar>
      </AppBar>
      <Box
        component="nav"
        sx={{ width: { sm: drawerWidth }, flexShrink: { sm: 0 } }}
        aria-label="mailbox folders"
      >
       
        <Drawer
          container={container}
          variant="temporary"
          open={mobileOpen}
          onClose={handleDrawerToggle}
          ModalProps={{
            keepMounted: true, 
          }}
          sx={{
            display: { xs: "block", sm: "none" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
        >
          {drawer}
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{
            display: { xs: "none", sm: "block" },
            "& .MuiDrawer-paper": {
              boxSizing: "border-box",
              width: drawerWidth,
            },
          }}
          open
        >
          {drawer}
        </Drawer>
      </Box>
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: { sm: `calc(100% - ${drawerWidth}px)` },
        }}
      >
        <Toolbar />
        {/* <Home/> */}
        <Switch>
          <Route exact path='/'>
              <Home/>
          </Route>
          <Route path='/settings'>
              <SettingsPage/>
          </Route>
          <Route path='/source'>
              <SourcePage/>
          </Route>
          <Route path='/insights'>
              <Insightpage/>
          </Route>
        </Switch>

        {/* <FileUpload />

        <Box component="span" sx={{ p: 2, width: 300, height: 300 }}>
        </Box>
        <Grid container spacing={3} my={-0.9} justifyContent="center">
          <Card desc="Score" dataArray={[2,6]}/>
          <Card desc="Completeness" dataArray={[3,4]}/>
          <Card desc="Uniqueness" dataArray={[1,6]}/>
        </Grid>
        <Bargraph1/>
        <Linegraph/> */}
      </Box>
    </Box>
    </Router>
  );
}

ResponsiveDrawer.propTypes = {
  window: PropTypes.func,
};

export default ResponsiveDrawer;
