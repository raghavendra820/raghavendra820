

// import {
//   PieChart,
//   Pie,
//   Tooltip,
//   BarChart,
//   XAxis,
//   YAxis,
//   Legend,
//   CartesianGrid,
//   Bar,
// } from "recharts";

// const App = () => {
//   const data = [
//     { name: "Nausea", users: 200000 },
//     { name: "Diaherria", users: 150000 },
//     { name: "headache", users: 100000 },
//     { name: "Vomiting", users: 500000 },
//     // { name: "Vomiting", users: 500000000 },
//   ];

//   return (
//     <div style={{ textAlign: "center" ,margin:'40px'}}>
//       <h2>Top 20 Most Common Side effects</h2>
//       <div className="App">
//         <BarChart
//           width={500}
//           height={300}
//           data={data}
//           margin={{
//             top: 5,
//             right: 30,
//             left: 80,
//             bottom: 5,
//           }}
//           barSize={20}
//         >
//           <XAxis
//             dataKey="name"
//             scale="point"
//             padding={{ left: 10, right: 10 }}
// 			// margin={{top: 10, bottom: 10 }}
//           />
//           <YAxis />
//           <Tooltip />
//           <Legend />
//           <CartesianGrid strokeDasharray="5 5" />
//           <Bar dataKey="users" fill="#1e90ff" background={{ fill: "#eee" }} />
//         </BarChart>
//       </div>
//     </div>
//   );
// };

// export default App;
//----------------------------------------------------------------------------- 

import React from 'react'

import { BarChart, ResponsiveContainer, XAxis,Bar, YAxis ,Tooltip} from 'recharts'
const Array=[{
  name:"Nausea",
  responses:"3500",
},
{
  name:"Diarrhea",
  responses:"10000",
},{
  name:"HeadAche",
  responses:"10000",
},{
  name:"Vomiting",
  responses:"35000",
},{
  name:"Rash",
  responses:"30000",
},{
  name:"Dizziness",
  responses:"29000",
},{
  name:"Fatigue",
  responses:"28000",
},
{
  name:"Insomnia",
  responses:"28000",
},
{
  name:"Edema",
  responses:"28000",
},
]

const Bargraph = () => {
  return (
     <ResponsiveContainer width='100%'  height='30%' aspect={3} >
    <div class="niguuu" style={{ textAlign: "center" ,margin:'40px',alignContent:'center',marginTop:'100px'}}>
      <h1 style={{ }}>Bargraph</h1>
      <BarChart data={Array} width={780} height={250} barSize={25}>
        <XAxis dataKey="name"/>
        <YAxis/>
        <Tooltip/>
        <Bar dataKey="responses" fill='#1e90ff'/>  
      </BarChart>

    </div>
     </ResponsiveContainer>
  )
}

export default Bargraph
// import React from 'react'
// import Paper from '@mui/material/Paper';
// import {
//   ArgumentAxis,
//   ValueAxis,
//   Chart,
//   BarSeries,
// } from '@devexpress/dx-react-chart-material-ui';

// const Bargraph = () => {
//   const data = [
//     { argument: 'Monday', value: 30 },
//     { argument: 'Tuesday', value: 20 },
//     { argument: 'Wednesday', value: 10 },
//     { argument: 'Thursday', value: 50 },
//     { argument: 'Friday', value: 60 },
//   ];
//   return (
//       <Paper>
//       <Chart
//         data={data}
//       >
//         <ArgumentAxis />
//         <ValueAxis />
    
//         <BarSeries valueField="value" argumentField="argument" />
//       </Chart>
//     </Paper>
//   );
//   }


// export default Bargraph