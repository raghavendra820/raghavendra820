// import React from 'react';
// import { Grid, Card, CardContent, Typography } from '@mui/material';
// import DoughNut from './DoughNut';

// const SimpleCard = (props) => {
//   var cardStyle = {
//     display: 'block',
//     width: '30vw',
//     transitionDuration: '0.3s',
//     height: '45vw'
// }
//   return (
//     <Grid item xs={6} md={2.4} lg={4}> 

//         <Card classes={cardStyle}>
//           <CardContent>
//             <DoughNut/>
//           </CardContent>
//         </Card>
//     </Grid>
//   );
// };


import * as React from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import DoughNut from './DoughNut';
import { CardHeader, Grid } from '@mui/material';

// const bull = (
//   <Box
//     component="span"
//     sx={{ display: 'inline-block', mx: '2px', transform: 'scale(0.8)' }}
//   >
//     •
//   </Box>
// );

// export default function BasicCard() {
//   return (
//     <Grid item lg={3} sm={3}>
//     <Card sx={{ maxWidth: 150 ,height:230}}>
//       <CardHeader
//       subheader="Score" subColor='text.primary'/>
//       <CardContent >
//         <DoughNut/>
//       </CardContent>
      
//     </Card>
//   </Grid>
//   );
// }



const Card1 = (props) => {
  return (
    <Grid item lg={3} sm={6} md={3} sx={4} >
     <Card sx={{ maxWidth: 150 ,height:230}}>
       <CardHeader
      subheader={props.desc} subColor='text.primary'/>
      <CardContent sx={{ maxWidth: 150 ,height:230}} >
        <DoughNut dataArray={props.dataArray}/>
      </CardContent>
      
    </Card>
  </Grid>
  )
}

export default Card1

