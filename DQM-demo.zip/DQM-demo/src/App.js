import logo from "./logo.svg";
import "./App.css";
import "./Components/Navbar";
import Navbar from "./Components/Navbar";
import Card from "./Components/Card";
import Drawer from "./Components/Drawer";
import { Box, Grid } from "@mui/material";
import SettingsPage from "./Pages/SettingsPage";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import Home from "./Components/Home";
// import SettingsPage from "./Pages/SettingsPage";
// import logo from './logo192.png';

function App() {
  return (
      <Switch>
        <Route exact path='/'>
          <Drawer/>
        </Route>
        <Route exact path='/settings'>
          <SettingsPage />
        </Route>
      </Switch>        
    
  );
}

export default App;
