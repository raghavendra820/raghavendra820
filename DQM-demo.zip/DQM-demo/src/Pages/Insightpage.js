import React from 'react'

const Insightpage = () => {
  return (
    <div>Insightpage</div>
  )
}

export default Insightpage